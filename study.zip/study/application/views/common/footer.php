<!-- Footer -->
<footer class="content-footer">
    <div>© 2020 Muson - <a href="http://studyplan4u.com/" target="_blank">Laborasyon</a></div>
    <div>
        <nav class="nav">
            <a href="http://studyplan4u.com/" class="nav-link">Licenses</a>
            <a href="#" class="nav-link">Change Log</a>
            <a href="#" class="nav-link">Get Help</a>
        </nav>
    </div>
</footer>
<!-- ./ Footer -->
</div>
<!-- ./ Content body -->
</div>
<!-- ./ Content wrapper -->
</div>
<!-- ./ Layout wrapper -->

<!-- Main scripts -->
<script src="<?php echo base_url(); ?>assets/vendors/bundle.js"></script>

<!-- To use theme colors with Javascript -->
<div class="colors">
    <div class="bg-primary"></div>
    <div class="bg-primary-bright"></div>
    <div class="bg-secondary"></div>
    <div class="bg-secondary-bright"></div>
    <div class="bg-info"></div>
    <div class="bg-info-bright"></div>
    <div class="bg-success"></div>
    <div class="bg-success-bright"></div>
    <div class="bg-danger"></div>
    <div class="bg-danger-bright"></div>
    <div class="bg-warning"></div>
    <div class="bg-warning-bright"></div>
</div>

<!-- Apex chart -->
<script src="<?php echo base_url(); ?>assets/irregular-data-series.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/charts/apex/apexcharts.min.js"></script>

<!-- Daterangepicker -->
<script src="<?php echo base_url(); ?>assets/vendors/datepicker/daterangepicker.js"></script>

<!-- DataTable -->
<script src="<?php echo base_url(); ?>assets/vendors/dataTable/datatables.min.js"></script>

<!-- Vamp -->
<script src="<?php echo base_url(); ?>assets/vendors/vmap/jquery.vmap.min.js"></script>
<script src=<?php echo base_url(); ?>"assets/vendors/vmap/maps/jquery.vmap.usa.js"></script>
<script src="<?php echo base_url(); ?>assets/js/examples/vmap.js"></script>

<!-- Dashboard scripts -->
<script src="<?php echo base_url(); ?>assets/js/examples/pages/ecommerce-dashboard.js"></script>

<!-- App scripts -->
<script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
</body>

<!-- Mirrored from muson.laborasyon.com/layouts/vertical/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 21 May 2022 07:59:38 GMT -->
</html>
