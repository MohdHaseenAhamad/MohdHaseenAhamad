<?php
/**
 * Created by PhpStorm.
 * User: MG-CLIENT-14
 * Date: 5/23/2022
 * Time: 5:20 PM
 */

class admin extends CI_Controller {

    public function index()
    {
        $this->load->view('index');
    }
}