<?php
/**
 * Created by PhpStorm.
 * User: MG-CLIENT-14
 * Date: 5/23/2022
 * Time: 4:19 PM
 */

class Index extends CI_Controller {

    public function index()
    {
        $this->load->view('index');
    }
}